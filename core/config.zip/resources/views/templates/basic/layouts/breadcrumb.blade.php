@php
    $breadcrumb = getContent('breadcrumb.content',true);
@endphp

<!-- Hero Section -->
<div class="wrapper">
      <div class="container">
        <div class="row">
        <h2 class="text-white">{{ __($page_title) }}</h2>
    </div>
</section>
<!-- Hero Section -->
