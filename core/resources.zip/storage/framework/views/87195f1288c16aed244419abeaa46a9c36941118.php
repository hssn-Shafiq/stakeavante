<?php echo  tawkto() ?>
<?php echo  analytics() ?><?php /**PATH C:\xampp\htdocs\stakeavante\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>