
<div class="row align-items-center mb-30 justify-content-between">
    <div class="col-lg-6 col-6">
        <h6 class="page-title"><?php echo e($page_title); ?></h6>
    </div>
    <div class="col-lg-6 col-6 text-right">
        <?php echo $__env->yieldPushContent('breadcrumb-plugins'); ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\techSphereLogix\stakeavante\core\resources\views/templates/basic/user/partials/breadcrumb.blade.php ENDPATH**/ ?>