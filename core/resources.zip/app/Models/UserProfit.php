<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class UserProfit extends Model
{    use HasFactory;
    protected $fillable = ['user_id', 'profit', 'amount'];
    
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the user that received the profit
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    
    /**
     * Get user's profit for a specific date
     * 
     * @param int $userId
     * @param string $date Format: Y-m-d
     * @return UserProfit|null
     */
    public static function getUserProfitForDate($userId, $date = null)
    {
        $date = $date ?? Carbon::now()->format('Y-m-d');
        
        return self::where('user_id', $userId)
            ->whereDate('created_at', $date)
            ->first();
    }
}
